import React from 'react';

const Wishlist = () => {
  return (
    <div>
      <h1>wishlist todo</h1>
    </div>
  );
};

export default Wishlist;