import React from 'react';

const MyList = () => {
  return (
    <div>
      <h1>My List</h1>
    </div>
  );
};

export default MyList;
